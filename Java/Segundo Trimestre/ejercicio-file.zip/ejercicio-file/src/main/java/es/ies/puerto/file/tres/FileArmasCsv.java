package es.ies.puerto.file.tres;

import java.util.List;

public class FileArmasCsv {

    public List<Arma> obtenerArmas() {
        return null;
    }
    public Arma obtenerArma(Arma arma) {
        return null;
    }
    public void addArma(Arma arma) {

    }
    public void deleteArma(Arma arma) {

    }
    public void updateArma(Arma arma) {

    }
}
