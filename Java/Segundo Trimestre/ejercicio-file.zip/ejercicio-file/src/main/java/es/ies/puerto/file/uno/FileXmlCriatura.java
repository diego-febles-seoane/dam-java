package es.ies.puerto.file.uno;

import java.util.List;

public class FileXmlCriatura {

    public List<Criatura> obtenerCriaturas() {
        return null;
    }
    public Criatura obtener(Criatura criatura) {
        return null;
    }
    public void addCriatura(Criatura criatura) {
    }
    public void deleteCriatura(Criatura criatura) {

    }
    public void updateCriatura(Criatura criatura) {

    }
}
