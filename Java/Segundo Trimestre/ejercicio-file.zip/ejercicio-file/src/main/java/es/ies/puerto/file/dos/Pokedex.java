package es.ies.puerto.file.dos;

import java.util.List;

public class Pokedex {
    List<Pokemon> pokemons;
}
