package es.ies.puerto.file.dos;

import java.util.List;

public class FilePokedexXml {

    public List<Pokemon> obtenerPokemons() {
        return null;
    }
    public Pokemon obtenerPokemon(Pokemon pokemon) {
        return null;
    }
    public void addPokemon(Pokemon pokemon) {

    }
    public void deletePokemon(Pokemon pokemon) {

    }
    public void updatePokemon(Pokemon pokemon) {

    }

}
