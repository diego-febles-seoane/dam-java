package es.ies.puerto;

public class Ejercicio13 {
    /**
    * Dos equipos de superhéroes han decidido fusionarse para enfrentar una amenaza mayor. Escribe un programa que combine ambos equipos en un solo array, sin que se repita ningún nombre.
    * @author diego-febles-seone
    * @version 1.0.0
    */
    public static void main(String[] args) {
        String[] equipo1 = {"Ironman", "Thor", "Hulk"};
        String[] equipo2 = {"Capitán América", "Thor", "Hawkeye"};
        
        String[] equipoUnido = new String[equipo1.length + equipo2.length];
            
    }    
}